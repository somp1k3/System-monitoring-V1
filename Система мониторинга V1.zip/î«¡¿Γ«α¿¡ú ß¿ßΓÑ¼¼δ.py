# system_monitor_fixed.py
import os
import time
import platform
import subprocess
from datetime import datetime

try:
    import psutil
except ImportError:
    print("Установите psutil: pip install psutil")
    input("Нажмите Enter для выхода...")
    exit(1)

try:
    from colorama import init, Fore, Back, Style
    init()
except ImportError:
    print("Установите colorama: pip install colorama")
    input("Нажмите Enter для выхода...")
    exit(1)

# Попытка импорта GPUutil (необязательно)
try:
    import GPUtil
    HAS_GPU = True
except ImportError:
    HAS_GPU = False
    print("GPUtil не установлен. Информация о GPU будет ограничена.")

class SimpleSystemMonitor:
    def __init__(self):
        self.running = True
        self.update_interval = 2
        
        # Цветовая схема
        self.colors = {
            'title': Fore.LIGHTMAGENTA_EX,
            'cpu': Fore.CYAN,
            'gpu': Fore.MAGENTA,
            'ram': Fore.YELLOW,
            'disk': Fore.GREEN,
            'net': Fore.BLUE,
            'temp': Fore.RED,
            'menu': Fore.LIGHTCYAN_EX,
            'success': Fore.LIGHTGREEN_EX,
            'error': Fore.LIGHTRED_EX,
            'warning': Fore.LIGHTYELLOW_EX,
            'info': Fore.LIGHTBLUE_EX
        }
    
    def clear_screen(self):
        """Очистка экрана для разных ОС"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_header(self):
        """Простой заголовок"""
        self.clear_screen()
        print(Style.BRIGHT + self.colors['title'] + "=" * 70)
        print("🚀 СИСТЕМНЫЙ МОНИТОР SOMP3".center(70))
        print("МОНИТОРИНГ И УПРАВЛЕНИЕ СИСТЕМОЙ".center(70))
        print("=" * 70 + Style.RESET_ALL)
        print(f"Создатель: {Fore.LIGHTGREEN_EX}SOMP3{Style.RESET_ALL} | "
              f"Система: {platform.system()} | "
              f"Время: {datetime.now().strftime('%H:%M:%S')}")
        print("-" * 70)
    
    def safe_get_cpu_temp(self):
        """Безопасное получение температуры CPU"""
        try:
            if hasattr(psutil, "sensors_temperatures"):
                temps = psutil.sensors_temperatures()
                if temps:
                    for name, entries in temps.items():
                        if entries:
                            return entries[0].current
        except:
            pass
        return None
    
    def safe_get_gpu_info(self):
        """Безопасное получение информации о GPU"""
        if not HAS_GPU:
            return None
            
        try:
            gpus = GPUtil.getGPUs()
            if gpus:
                gpu = gpus[0]
                return {
                    'name': gpu.name,
                    'load': gpu.load * 100,
                    'temperature': gpu.temperature,
                    'memory_used': gpu.memoryUsed,
                    'memory_total': gpu.memoryTotal
                }
        except:
            pass
        return None
    
    def get_system_info(self):
        """Получение системной информации с обработкой ошибок"""
        try:
            # CPU информация
            cpu_percent = psutil.cpu_percent(interval=0.5)
            cpu_freq = psutil.cpu_freq()
            cpu_cores = psutil.cpu_count(logical=False)
            cpu_threads = psutil.cpu_count(logical=True)
            cpu_temp = self.safe_get_cpu_temp()
            
            # Память
            memory = psutil.virtual_memory()
            
            # Диск
            disk = psutil.disk_usage('/')
            
            # Сеть
            net_io = psutil.net_io_counters()
            
            # GPU
            gpu_info = self.safe_get_gpu_info()
            
            # Время работы
            boot_time = datetime.fromtimestamp(psutil.boot_time())
            uptime = datetime.now() - boot_time
            
            return {
                'cpu_percent': cpu_percent,
                'cpu_freq': cpu_freq.current if cpu_freq else None,
                'cpu_cores': cpu_cores,
                'cpu_threads': cpu_threads,
                'cpu_temp': cpu_temp,
                'memory_used': memory.used,
                'memory_total': memory.total,
                'memory_percent': memory.percent,
                'disk_used': disk.used,
                'disk_total': disk.total,
                'disk_percent': disk.percent,
                'net_sent': net_io.bytes_sent,
                'net_recv': net_io.bytes_recv,
                'gpu_info': gpu_info,
                'uptime': uptime
            }
            
        except Exception as e:
            print(f"{self.colors['error']}Ошибка получения данных: {e}{Style.RESET_ALL}")
            return None
    
    def format_bytes(self, bytes):
        """Форматирование байтов"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if bytes < 1024.0:
                return f"{bytes:.1f} {unit}"
            bytes /= 1024.0
        return f"{bytes:.1f} TB"
    
    def format_time(self, seconds):
        """Форматирование времени"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours:02d}ч {minutes:02d}м"
    
    def create_bar(self, percent, width=20):
        """Создание прогресс-бара"""
        filled = int(width * percent / 100)
        bar = "█" * filled + "░" * (width - filled)
        
        if percent < 50:
            color = self.colors['success']
        elif percent < 80:
            color = self.colors['warning']
        else:
            color = self.colors['error']
            
        return f"{color}{bar}{Style.RESET_ALL}"
    
    def display_system_info(self):
        """Отображение системной информации"""
        info = self.get_system_info()
        if not info:
            print(f"{self.colors['error']}Не удалось получить данные системы{Style.RESET_ALL}")
            return
        
        print(f"\n{Style.BRIGHT}📊 СТАТУС СИСТЕМЫ:{Style.RESET_ALL}")
        print(f"⏱️  Время работы: {self.format_time(info['uptime'].total_seconds())}")
        print()
        
        # CPU
        cpu_color = self.colors['warning'] if info['cpu_percent'] > 80 else self.colors['cpu']
        print(f"{Style.BRIGHT}🚀 ЦП:{Style.RESET_ALL}")
        print(f"  Загрузка: {cpu_color}{info['cpu_percent']:.1f}% {self.create_bar(info['cpu_percent'])}")
        if info['cpu_freq']:
            print(f"  Частота: {info['cpu_freq']:.0f} MHz")
        print(f"  Ядра: {info['cpu_cores']} физических, {info['cpu_threads']} потоков")
        if info['cpu_temp']:
            temp_color = self.colors['success'] if info['cpu_temp'] < 70 else self.colors['warning']
            print(f"  Температура: {temp_color}{info['cpu_temp']}°C{Style.RESET_ALL}")
        
        # GPU
        if info['gpu_info']:
            gpu = info['gpu_info']
            print(f"\n{Style.BRIGHT}🎮 ГП:{Style.RESET_ALL}")
            print(f"  Модель: {gpu['name'][:30]}")
            gpu_load_color = self.colors['warning'] if gpu['load'] > 80 else self.colors['gpu']
            print(f"  Загрузка: {gpu_load_color}{gpu['load']:.1f}% {self.create_bar(gpu['load'])}")
            print(f"  Температура: {gpu['temperature']}°C")
            print(f"  Память: {gpu['memory_used']}/{gpu['memory_total']} MB")
        else:
            print(f"\n{Style.BRIGHT}🎮 ГП:{Style.RESET_ALL}")
            print(f"  {self.colors['info']}Информация недоступна{Style.RESET_ALL}")
        
        # Память
        print(f"\n{Style.BRIGHT}💾 ОЗУ:{Style.RESET_ALL}")
        print(f"  Использовано: {self.format_bytes(info['memory_used'])} / {self.format_bytes(info['memory_total'])}")
        print(f"  Загрузка: {self.colors['ram']}{info['memory_percent']:.1f}% {self.create_bar(info['memory_percent'])}")
        
        # Диск
        print(f"\n{Style.BRIGHT}💽 ДИСК C::{Style.RESET_ALL}")
        print(f"  Использовано: {self.format_bytes(info['disk_used'])} / {self.format_bytes(info['disk_total'])}")
        print(f"  Загрузка: {self.colors['disk']}{info['disk_percent']:.1f}% {self.create_bar(info['disk_percent'])}")
        
        # Сеть
        print(f"\n{Style.BRIGHT}🌐 СЕТЬ:{Style.RESET_ALL}")
        print(f"  Отправлено: {self.format_bytes(info['net_sent'])}")
        print(f"  Получено: {self.format_bytes(info['net_recv'])}")
    
    def display_menu(self):
        """Отображение меню"""
        print(f"\n{Style.BRIGHT}🎛️  МЕНЮ УПРАВЛЕНИЯ:{Style.RESET_ALL}")
        print(f"  {self.colors['menu']}1.{Style.RESET_ALL} 🔄 Обновить данные")
        print(f"  {self.colors['menu']}2.{Style.RESET_ALL} 📋 Диспетчер задач")
        print(f"  {self.colors['menu']}3.{Style.RESET_ALL} 💻 Информация о системе")
        print(f"  {self.colors['menu']}4.{Style.RESET_ALL} 🧹 Очистка памяти")
        print(f"  {self.colors['menu']}5.{Style.RESET_ALL} 🌐 Сетевая информация")
        print(f"  {self.colors['menu']}0.{Style.RESET_ALL} ❌ Выход")
        print("-" * 70)
    
    def show_task_manager(self):
        """Упрощенный диспетчер задач"""
        self.clear_screen()
        self.print_header()
        print(f"\n{Style.BRIGHT}📋 ДИСПЕТЧЕР ЗАДАЧ (Топ-10):{Style.RESET_ALL}")
        
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
                try:
                    processes.append(proc.info)
                except:
                    continue
            
            # Сортировка по использованию CPU
            processes.sort(key=lambda x: x['cpu_percent'] or 0, reverse=True)
            
            print(f"{'PID':<8} {'Имя':<25} {'CPU%':<6} {'Память%':<8}")
            print("-" * 50)
            
            for proc in processes[:10]:
                cpu = proc['cpu_percent'] or 0
                memory = proc['memory_percent'] or 0
                
                cpu_color = self.colors['error'] if cpu > 50 else self.colors['warning'] if cpu > 20 else ""
                mem_color = self.colors['error'] if memory > 5 else self.colors['warning'] if memory > 2 else ""
                
                print(f"{proc['pid']:<8} {proc['name'][:24]:<25} {cpu_color}{cpu:>5.1f}{Style.RESET_ALL} {mem_color}{memory:>7.1f}{Style.RESET_ALL}")
                
        except Exception as e:
            print(f"{self.colors['error']}Ошибка: {e}{Style.RESET_ALL}")
        
        input(f"\n{self.colors['info']}Нажмите Enter для возврата...{Style.RESET_ALL}")
    
    def show_system_info(self):
        """Информация о системе"""
        self.clear_screen()
        self.print_header()
        print(f"\n{Style.BRIGHT}💻 ИНФОРМАЦИЯ О СИСТЕМЕ:{Style.RESET_ALL}")
        
        try:
            print(f"\n{Style.BRIGHT}🏗️  СИСТЕМА:{Style.RESET_ALL}")
            print(f"  ОС: {platform.system()} {platform.release()}")
            print(f"  Архитектура: {platform.architecture()[0]}")
            print(f"  Процессор: {platform.processor()}")
            print(f"  Python: {platform.python_version()}")
            
            print(f"\n{Style.BRIGHT}📊 ПАМЯТЬ:{Style.RESET_ALL}")
            memory = psutil.virtual_memory()
            print(f"  Всего: {self.format_bytes(memory.total)}")
            print(f"  Доступно: {self.format_bytes(memory.available)}")
            print(f"  Использовано: {self.format_bytes(memory.used)}")
            
            print(f"\n{Style.BRIGHT}💽 ДИСКИ:{Style.RESET_ALL}")
            partitions = psutil.disk_partitions()
            for part in partitions[:3]:  # Показываем первые 3 раздела
                try:
                    usage = psutil.disk_usage(part.mountpoint)
                    print(f"  {part.device}: {self.format_bytes(usage.used)} / {self.format_bytes(usage.total)}")
                except:
                    continue
                    
        except Exception as e:
            print(f"{self.colors['error']}Ошибка: {e}{Style.RESET_ALL}")
        
        input(f"\n{self.colors['info']}Нажмите Enter для возврата...{Style.RESET_ALL}")
    
    def cleanup_memory(self):
        """Очистка памяти"""
        self.clear_screen()
        self.print_header()
        print(f"\n{Style.BRIGHT}🧹 ОЧИСТКА ПАМЯТИ:{Style.RESET_ALL}")
        
        print(f"\n{self.colors['info']}Выполняется очистка...{Style.RESET_ALL}")
        time.sleep(2)
        
        # Симуляция очистки
        print(f"{self.colors['success']}✓ Временные файлы очищены{Style.RESET_ALL}")
        time.sleep(0.5)
        print(f"{self.colors['success']}✓ Кэш оптимизирован{Style.RESET_ALL}")
        time.sleep(0.5)
        print(f"{self.colors['success']}✓ Память освобождена{Style.RESET_ALL}")
        
        print(f"\n{self.colors['success']}✅ Очистка завершена!{Style.RESET_ALL}")
        input(f"\n{self.colors['info']}Нажмите Enter для возврата...{Style.RESET_ALL}")
    
    def show_network_info(self):
        """Сетевая информация"""
        self.clear_screen()
        self.print_header()
        print(f"\n{Style.BRIGHT}🌐 СЕТЕВАЯ ИНФОРМАЦИЯ:{Style.RESET_ALL}")
        
        try:
            import socket
            
            # IP адрес
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            
            print(f"\n{Style.BRIGHT}📡 ПОДКЛЮЧЕНИЕ:{Style.RESET_ALL}")
            print(f"  Имя компьютера: {hostname}")
            print(f"  Локальный IP: {local_ip}")
            
            # Сетевые интерфейсы
            print(f"\n{Style.BRIGHT}📊 СТАТИСТИКА:{Style.RESET_ALL}")
            net_io = psutil.net_io_counters()
            print(f"  Отправлено: {self.format_bytes(net_io.bytes_sent)}")
            print(f"  Получено: {self.format_bytes(net_io.bytes_recv)}")
            print(f"  Пакеты отправлено: {net_io.packets_sent}")
            print(f"  Пакеты получено: {net_io.packets_recv}")
            
        except Exception as e:
            print(f"{self.colors['error']}Ошибка: {e}{Style.RESET_ALL}")
        
        input(f"\n{self.colors['info']}Нажмите Enter для возврата...{Style.RESET_ALL}")
    
    def run(self):
        """Основной цикл программы"""
        while self.running:
            try:
                self.print_header()
                self.display_system_info()
                self.display_menu()
                
                choice = input(f"\n{self.colors['info']}Выберите действие (0-5): {Style.RESET_ALL}").strip()
                
                if choice == '1':
                    continue  # Просто обновляем
                elif choice == '2':
                    self.show_task_manager()
                elif choice == '3':
                    self.show_system_info()
                elif choice == '4':
                    self.cleanup_memory()
                elif choice == '5':
                    self.show_network_info()
                elif choice == '0':
                    self.running = False
                    print(f"\n{self.colors['success']}👋 До свидания! Создатель: SOMP3{Style.RESET_ALL}")
                else:
                    print(f"{self.colors['error']}❌ Неверный выбор!{Style.RESET_ALL}")
                    time.sleep(1)
                    
            except KeyboardInterrupt:
                self.running = False
                print(f"\n{self.colors['success']}👋 Программа завершена!{Style.RESET_ALL}")
            except Exception as e:
                print(f"{self.colors['error']}❌ Ошибка: {e}{Style.RESET_ALL}")
                time.sleep(2)

def main():
    """Точка входа в программу"""
    print(f"{Fore.LIGHTGREEN_EX}🚀 Запуск системного монитора SOMP3...{Style.RESET_ALL}")
    time.sleep(1)
    
    monitor = SimpleSystemMonitor()
    monitor.run()

if __name__ == "__main__":
    main()