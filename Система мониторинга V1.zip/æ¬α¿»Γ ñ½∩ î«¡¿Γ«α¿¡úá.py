# install_dependencies.py
import subprocess
import sys

def install_package(package):
    """Установка пакета"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"✅ {package} успешно установлен")
        return True
    except subprocess.CalledProcessError:
        print(f"❌ Ошибка установки {package}")
        return False

def main():
    print("🔧 Установка зависимостей для System Monitor SOMP3")
    print("=" * 50)
    
    packages = ["psutil", "colorama"]
    
    success_count = 0
    for package in packages:
        if install_package(package):
            success_count += 1
    
    print("=" * 50)
    if success_count == len(packages):
        print("🎉 Все зависимости успешно установлены!")
        print("Запустите: python system_monitor_fixed.py")
    else:
        print("⚠️ Некоторые зависимости не установлены")
        print("Программа может работать с ограниченным функционалом")
    
    input("\nНажмите Enter для выхода...")

if __name__ == "__main__":
    main()